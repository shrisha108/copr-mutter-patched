#pragma once

#include "clutter/clutter-types.h"

G_BEGIN_DECLS

void _clutter_actor_box_enlarge_for_effects (ClutterActorBox *box);

G_END_DECLS
