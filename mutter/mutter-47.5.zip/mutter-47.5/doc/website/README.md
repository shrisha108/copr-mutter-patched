# Mutter Website

This is the website for the mutter window manager. Feel free to fix typos and
suggest changes by opening MRs against the appropriate [gitlab
module](https://gitlab.gnome.org/GNOME/mutter/-/tree/main/doc/website).
